# Builds a function returning linear combination of  n inputs:
# a0 + a1*x1 + a2*x2 + ... + an*xn
#' @export
build_lincomb = function(num_inputs = 3, features = NULL, parameter_values = 0, name = paste0('LC', num_inputs)){
  niseq       = sequence(num_inputs)
  xseq        = paste0('x', niseq)  
  aseq        = paste0('a', niseq)
  ldep        = c(aseq, xseq) %>% as.list %>% {names(.) <- c(xseq, aseq);.} 
  ldep$a0     = c()
  ldep$output = c('a0', xseq, aseq)
  if(is.empty(features)){initial_inputs = numeric(num_inputs)} else {
    assert(length(features) == num_inputs)
    initial_inputs = features}
  if(is.empty(parameter_values)){initial_parameters = numeric(num_inputs + 1)} else {
    if(length(parameter_values) == 1){parameter_values = rep(parameter_values, num_inputs + 1)}
    assert(length(parameter_values) == num_inputs + 1)
    initial_parameters = parameter_values
  }
  
  new('FUNCTION', 
    name   = name, 
    type   = paste('linear combination of', num_inputs, 'inputs'),
    inputs = initial_inputs %>% as.list %>% {names(.) <- xseq;.},
    params = initial_parameters %>% as.list %>% {names(.) <- c('a0', aseq);.},
    rule.output   = function(inputs, params, objects){
      niseq = sequence(length(inputs))
      val   = params$a0
      for(i in niseq){
        inp = paste0('x', i)
        par = paste0('a', i)
        val = val + params[[par]]*inputs[[inp]]
      }
      return(val)
    },  
    rule.gradient = function(inputs, params, objects, wrt){
      if(wrt == 'a0') {return(1.0)}
      
      wrt %>% substr(1,1) -> ltr
      wrt %>% substr(2, nchar(wrt)) %>% as.integer -> num
      
      switch(ltr, 
             'x' = {params[[paste0('a', num)]]},
             'a' = {inputs[[paste0('x', num)]]})
    },
    local_dependencies = ldep)
}

# Builds a function returning sum of  n inputs:
# x1 + x2 + ... + xn
#' @export
build_sum = function(num_inputs = 3, features = NULL, name = paste0('SUM', num_inputs)){
  niseq       = sequence(num_inputs)
  xseq        = paste0('x', niseq)  
  ldep        = list(output = xseq)
  if(is.empty(features)){initial_inputs = numeric(num_inputs)} else {
    assert(length(features) == num_inputs)
    initial_inputs = features
  }
  
  new('FUNCTION', 
      name   = name, 
      type   = paste('sum of', num_inputs, 'inputs'),
      inputs = initial_inputs %>% as.list %>% {names(.) <- xseq;.},
      rule.output   = function(inputs, params, objects){
        niseq = sequence(length(inputs))
        val   = 0
        for(i in niseq){
          inp = paste0('x', i)
          val = val + inputs[[inp]]
        }
        return(val)
      },  
      rule.gradient = function(inputs, params, objects, wrt){
        if(wrt %in% names(inputs)) {return(1.0)} else {stop('Unknown wrt')}
      },
      local_dependencies = ldep)
}

# Builds a function returning product of  n inputs:
# x1*x2* ... *xn
#' @export
build_prod = function(num_inputs = 3, features = NULL, name = paste0('PROD', num_inputs)){
  niseq       = sequence(num_inputs)
  xseq        = paste0('x', niseq)  
  ldep        = list(output = xseq)
  for(inp in xseq){
    ldep[[inp]] = xseq %-% inp
  }
  if(is.empty(features)){initial_inputs = numeric(num_inputs)} else {
    assert(length(features) == num_inputs)
    initial_inputs = features
  }
  
  new('FUNCTION', 
      name   = name, 
      type   = paste('product of', num_inputs, 'inputs'),
      inputs = initial_inputs %>% as.list %>% {names(.) <- xseq;.},
      rule.output   = function(inputs, params, objects){
        niseq = sequence(length(inputs))
        val   = 1.0
        for(i in niseq){
          inp = paste0('x', i)
          val = val*inputs[[inp]]
        }
        return(val)
      },  
      rule.gradient = function(inputs, params, objects, wrt){
        niseq = sequence(length(inputs))
        xseq  = paste0('x', niseq)
        val   = 1.0
        for(inp in xseq %-% wrt){
          val = val*inputs[[inp]]
        }
        return(val)
      },
      local_dependencies = ldep)
}


# internal
dec2bin <- function(x, digits = 32){
  B = intToBits(x) %>% as.integer %>% matrix(nrow = length(x), byrow = T)
  B[, digits %>% sequence %>% rev] %>% apply(1, function(v) paste(v, collapse = ''))
}

#' @export
build_poly = function(num_inputs = 3, degree = 4, features = NULL, name = paste0('POLY', num_inputs, '_d', degree)){

  enrich = function(lst = c(), pm = 'x', degree = 3, wrt = 'output'){
    build_form = function(pm, degree, wrt){
      if(pm == wrt){
        if(degree > 2){
          return(c('1.0', paste(1 + sequence(degree - 1), c(pm, paste(pm, 1 + sequence(degree - 2), sep = '^')), sep = '_')))
        } else if (degree == 2){
          c('1.0', paste(2, pm, sep = '_'))
        } else {
          '1.0'
        }
      } else {
        if(degree > 1){
          return(c('1.0', pm, paste(pm, 1 + sequence(degree - 1), sep = '^')))
        } else {
          return(c('1.0', pm))
        }
      }
    }
    if(length(pm) == 1){
      if(is.empty(lst)){
        build_form(pm, degree, wrt)
      } else {
        ff = c()
        for(si in lst){
          sy = build_form(pm, degree, wrt)
          ff = c(ff, paste(si, sy, sep = '_'))
        }
        return(ff)
      }
    } else if (length(pm) > 1){
      ff = c()
      for (pmi in pm){
        ff = enrich(ff, pm = pmi, degree = degree, wrt = wrt)
      }
      return(ff)
    } else stop()
  }
  
  niseq = sequence(num_inputs)
  xseq0 = paste0('x', niseq)  
  xseq  = paste('inputs', xseq0, sep = '$')
  if(is.empty(features)){initial_inputs = numeric(num_inputs)} else {
    assert(length(features) == num_inputs)
    initial_inputs = features}
  
  terms = enrich(pm = xseq, degree = degree) %>% 
    gsub(pattern = '_1.0', replacement = '') %>% 
    gsub(pattern = '1.0_', replacement = '') %>% 
    gsub(pattern = '_', replacement = '*')
  
  basen = terms %>% length %>% sequence %>% {.-1} %>% 
    cwhmisc::r2B(base = degree + 1) %>% {.$s} %>% 
    stringr::str_trim("right") %>% stringr::str_pad(num_inputs, pad = "0")
  
  parlist0 = paste0('a', basen)
  parlist  = paste0('params$a', basen)
  form     = terms %>% as.list %>% {names(.)<-parlist0;.}
  ldep     = basen %>% strsplit(split = '') %>% lapply(function(u) 'x' %++% which(u > 0)) %>% {names(.)<-parlist0;.}
  ldep$output = c(paste0('a', basen), paste0('x', niseq))
  form$output = c(parlist[1], paste(parlist[-1], terms[-1], sep = '*')) %>% paste(collapse = " + ")
  for(i in niseq){
    inp   <- xseq0[i]
    terms <- enrich(pm = xseq, degree = degree, wrt = xseq[i]) %>% 
      gsub(pattern = '_1.0', replacement = '') %>% 
      gsub(pattern = '1.0_', replacement = '') %>% 
      gsub(pattern = '_', replacement = '*')
    
    parlist0 = paste0('a', basen[- which(substr(basen, i, i) == '0')])
    parlist  = paste('params', parlist0, sep = '$')

    form[[inp]] <- c(parlist[1],  paste(parlist[-1], terms[-1], sep = '*')) %>% paste(collapse = ' + ')
    ldep[[inp]] <- c(parlist0, xseq0)
  }
  
  new('FUNCTION', 
      name    = name, 
      type    = paste('polynomial of', num_inputs, 'inputs of degree', degree),
      inputs  = initial_inputs %>% as.list %>% {names(.) <- xseq0;.},
      params  = basen %>% length %>% numeric %>% as.list %>% {names(.)<-paste0('a', basen);.},
      objects = list(formulas = form),
      
      rule.output   = function(inputs, params, objects){
        parse(text = objects$formulas$output) %>% eval
      },  
      rule.gradient = function(inputs, params, objects, wrt){
        parse(text = objects$formulas[[wrt]]) %>% eval
      },
      local_dependencies = ldep)
}

#' @export
build_binbin = function(num_inputs = 3, features = NULL, name = paste0('BINBIN', num_inputs)){
  # assert num_inputs <= 32
  nseq  = sequence(num_inputs)
  xseq  = paste0('x', nseq)  
  cseq  = paste0('c', nseq)
  
  if(is.empty(features)){initial_inputs = runif(num_inputs)} else {
    assert(length(features) == num_inputs)
    initial_inputs = features
  }
  base2 = dec2bin(sequence(2^num_inputs) - 1, digits = num_inputs)
  aseq  = paste0('a', base2)
  b2tab = base2 %>% strsplit('') %>% as.data.frame %>% as.matrix %>% t %>% apply(2, as.integer) %>% 
    as.data.frame %>% {names(.)<-xseq;.}
  
  ldep  = list(output = c(xseq, cseq, aseq))
  for(pm in c(xseq, cseq, aseq)){ldep[[pm]] <- c(xseq, cseq, aseq)}
  new('FUNCTION', 
      name    = name, 
      type    = paste('binary binner of', num_inputs, 'inputs'),
      inputs  = initial_inputs %>% as.list %>% {names(.) <- xseq;.},
      
      params  = numeric(2^num_inputs + num_inputs) %>% as.list %>% {names(.)<-c(aseq, cseq);.},
      objects = list(base = b2tab), 
      rule.output   = function(inputs, params, objects){
        nseq = sequence(length(inputs))
        cseq = paste0('c', nseq)   
        inputs %>% as.data.frame %>% {for(i in nseq){.[,i]=as.integer(.[,i]>params[[cseq[i]]])};.} %>% 
          left_join(objects$base %>% mutate(value = unlist(params %>% list.remove(cseq))), by = xseq) %>% pull(value)
      },  
      rule.gradient = function(inputs, params, objects, wrt){
        nseq = sequence(length(inputs))
        cseq = paste0('c', nseq)
        wrts = names(params) %-% cseq
        if(wrt %in% wrts){
          inputs %>% as.data.frame %>% {for(i in nseq){.[,i]=as.integer(.[,i]>params[[cseq[i]]])};.} %>% 
            left_join(objects$base %>% mutate(value = as.integer(wrts == wrt)), by = xseq) %>% pull(value)
        } else (stop('Either unknown wrt or gradient cannot be computed analytically!'))
      },
      local_dependencies = ldep)
}