# Header
# Filename:       rfun.R
# Description:    A toolbox for R programmers for working with functions
# Version History:
# 0.0.1 (28 September 2014)    - Initial Issue
# Description for Roxygen

#' biger
#'
#' This package is a tool-box for working with functions.
#' @author Nicolas Berta
#'
#' @docType package
#' @name rfun
#' 
#' @include funclass.R
#' @include funlib.R
#' @include funlib2.R
#' @include builders.R
#' @include funtools.R
#' @include solvers.R
