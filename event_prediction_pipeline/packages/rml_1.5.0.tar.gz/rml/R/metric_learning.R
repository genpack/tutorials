# Metric Learning Tools for Time Series:

get_feature_lags = function(X, id_col, time_col, feature){
  all_times = X %>% pull(time_col) %>% unique %>% sort
  
  
}
