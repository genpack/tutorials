```{r global, include=FALSE}
# load data in 'global' chunk so it can be shared by all users of the dashboard
data <- readr::read_csv("data.csv")
```