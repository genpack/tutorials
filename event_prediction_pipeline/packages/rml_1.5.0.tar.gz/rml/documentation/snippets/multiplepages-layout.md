---
title: "Multiple Pages"
output: flexdashboard::flex_dashboard
---

Page 1
=====================================  
    
Column {data-width=600}
-------------------------------------
    
### Chart 1
    
```{r}
```
   
Column {data-width=400}
-------------------------------------
   
### Chart 2

```{r}
```   
 
### Chart 3
    
```{r}
```

Page 2 {data-orientation=rows}
=====================================     
   
Row {data-height=600}
-------------------------------------

### Chart 1

```{r}
```

Row {data-height=400}
-------------------------------------
   
### Chart 2

```{r}
```   
    
### Chart 3

```{r}
```
