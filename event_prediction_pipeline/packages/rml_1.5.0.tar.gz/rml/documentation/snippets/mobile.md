---
title: "Mobile Specific Component"
output: flexdashboard::flex_dashboard
---

### Chart 1
    
```{r}
plot(cars)
```
    
### Chart 1 {.mobile}

```{r}
plot(cars)
```
