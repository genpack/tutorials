---
title: "Page Links"
output: flexdashboard::flex_dashboard
---

Page 1
===================================== 

You can link to a dashboard page with either of the following syntaxes:

[Page 2]

[Page Two](#page-2)

The second syntax is used when you want a custom name for the link 
(rather than just using the page title).

### Chart A
    
```{r}
```

Page 2
=====================================     

### Chart B
    
```{r}
```
