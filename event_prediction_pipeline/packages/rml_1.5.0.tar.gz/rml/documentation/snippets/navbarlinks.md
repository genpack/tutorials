---
title: "Navigation Bar"
output: 
  flexdashboard::flex_dashboard:
    navbar:
      - { title: "About", href: "https://example.com/about", align: left }
---
