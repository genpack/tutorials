---
title: "Page Icons"
output: flexdashboard::flex_dashboard
---

Page 1 {data-icon="fa-list"}
=====================================


Page 2 {data-icon="fa-hashtag"}
=====================================  
