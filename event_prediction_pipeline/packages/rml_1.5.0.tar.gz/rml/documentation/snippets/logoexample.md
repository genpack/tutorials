---
title: "Logo and Favicon"
output: 
  flexdashboard::flex_dashboard:
    logo: logo.png
    favicon: favicon.png
---
