---
title: "Row Orientation"
output: 
  flexdashboard::flex_dashboard:
    orientation: rows
---
    
Row
-------------------------------------
    
### Chart 1
    
```{r}

```
   
Row
-------------------------------------
    
### Chart 2
    
```{r}

```
    
### Chart 3

```{r}

```
