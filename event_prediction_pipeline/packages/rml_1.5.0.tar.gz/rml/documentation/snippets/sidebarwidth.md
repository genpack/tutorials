---
title: "Sidebar Width"
output: flexdashboard::flex_dashboard 
runtime: shiny
---

Inputs {.sidebar data-width=300}
-----------------------------------------------------------------------

```{r}
# shiny inputs defined here
```
