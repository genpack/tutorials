```{r}
# include the module
source("worldPhones.R")

# call the module
worldPhonesUI("phones")
callModule(worldPhones, "phones")
```